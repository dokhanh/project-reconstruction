package Jcg;

import Jcg.geometry.*;

public class TestJcg {

    public static void main (String[] args) {
    }
 
}
